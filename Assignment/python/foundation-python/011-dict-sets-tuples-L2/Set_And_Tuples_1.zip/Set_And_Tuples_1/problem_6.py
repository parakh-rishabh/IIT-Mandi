tupp=(10, 9, 8, 7, 6, 5)
k=9
if k in tupp:
    print(True)
else:
    print(False)    