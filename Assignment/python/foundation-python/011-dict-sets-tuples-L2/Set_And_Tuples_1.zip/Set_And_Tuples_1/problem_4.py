arr=[5, 10, 7, 4, 15, 3]
tupp=tuple(arr)
print(tupp)