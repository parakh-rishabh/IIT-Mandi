tupp=(8, 2, 3, 0, 7)
sum=0
for i in tupp:
    sum=sum+i
print(sum)    