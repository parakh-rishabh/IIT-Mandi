arr=[4, 65, 32, 2, 104, 78, 10]
maxi=max(arr)
print(maxi)